﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Telegram.Bot;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.ReplyMarkups;

class Program
{
    private static ITelegramBotClient client;
    private static ReceiverOptions receiverOptions;
    private static string token = "7174566805:AAHwvZl1JiCSMU4AG2hgqUgyhRbHzIhEycY"; // Замените на ваш токен
    private static string jsonFilePath = "raffles.json"; // Путь к файлу для сохранения розыгрышей
    private static string historyJsonFilePath = "raffleHistory.json"; // Путь к файлу для истории
    private static List<Raffle> raffles = new List<Raffle>();
    private static List<Raffle> raffleHistory = new List<Raffle>();
    private static Timer raffleTimer;
    private static TimeSpan checkInterval = TimeSpan.FromMinutes(0.1); // Интервал проверки таймера

    public static void Main(string[] args)
    {
        InitializeBot();

        LoadRaffles();
        ScheduleRaffleCheck();

        var cts = new CancellationTokenSource();
        client.StartReceiving(UpdateHandler, ErrorHandler, receiverOptions, cts.Token);

        Console.WriteLine("Бот работает в автономном режиме!");
        Console.ReadLine();
        Console.WriteLine("Бот остановлен полностью");
    }

    private static void InitializeBot()
    {
        client = new TelegramBotClient(token);
        receiverOptions = new ReceiverOptions
        {
            AllowedUpdates = new[] { UpdateType.Message, UpdateType.CallbackQuery }
        };
    }

    private static void ScheduleRaffleCheck()
    {
        raffleTimer = new Timer(CheckRaffles, null, TimeSpan.Zero, checkInterval);
    }

    private static void CheckRaffles(object state)
    {
        var rafflesToDraw = raffles.Where(r => r.ScheduledTime <= DateTime.Now.TimeOfDay).ToList();
        foreach (var raffle in rafflesToDraw)
        {
            _ = SelectWinner(client, raffle);
            raffles.Remove(raffle);
            raffleHistory.Add(raffle);
        }
        SaveRaffles();
        SaveRaffleHistory();
    }

    private static async Task UpdateHandler(ITelegramBotClient client, Update update, CancellationToken token)
    {
        if (update.Type == UpdateType.Message && update.Message?.Text != null)
        {
            await HandleMessageUpdate(client, update.Message);
        }
        else if (update.Type == UpdateType.CallbackQuery)
        {
            await HandleCallbackQuery(client, update.CallbackQuery);
        }
    }

    private static async Task HandleMessageUpdate(ITelegramBotClient client, Message message)
    {
        var chatId = message.Chat.Id;
        if (message.Text == "/start")
        {
            await StartCommand(client, message);
        }
        else if (IsAdmin(chatId))
        {
            await HandleAdminCommands(client, message);
        }
        else
        {
            await client.SendTextMessageAsync(chatId, "** вы не администратор **");
        }
    }

    private static bool IsAdmin(long chatId)
    {
        List<long> adminIds = new List<long> { 882609514 };
        return adminIds.Contains(chatId);
    }

    private static async Task StartCommand(ITelegramBotClient client, Message message)
    {
        await client.SendTextMessageAsync(message.Chat.Id, $"Привет {message.From?.Username}!");

        var startKeyboard = new InlineKeyboardMarkup(new[]
        {
            InlineKeyboardButton.WithCallbackData("History", "show_history")
        });
        await client.SendTextMessageAsync(message.Chat.Id, "История розыгрышей", replyMarkup: startKeyboard);
        await ShowRaffles(client, message.Chat.Id);
    }

    private static async Task HandleAdminCommands(ITelegramBotClient client, Message message)
    {
        string command = message.Text.Split(' ').First();
        switch (command)
        {
            case "/admin":
                await ShowAdminPanel(client, message);
                break;
            case "/create":
                await CreateRaffle(client, message);
                break;
            case "/history":
                await ShowRaffleHistory(client, message.Chat.Id);
                break;
            case "/delete":
                await DeleteRaffle(client, message);
                break;
            case "/setimage":
                await SetRaffleImage(client, message);
                break;
            case "/edit":
                await EditRaffleName(client, message);
                break;
            case "/settime":
                await SetRaffleTime(client, message);
                break;
            case "/starte":
                await StartRaffle(client, message);
                break;
        }
    }

    private static async Task ShowAdminPanel(ITelegramBotClient client, Message message)
    {
        var chatId = message.Chat.Id;
        await client.SendTextMessageAsync(chatId, "Вы в панели администратора.\nСоздать розыгрыш: /create имя\n..." /* другие команды */, replyMarkup: AdminPanel());
    }

    private static async Task CreateRaffle(ITelegramBotClient client, Message message)
    {
        var parts = message.Text.Trim().Split(' ');
        if (parts.Length < 2)
        {
            await client.SendTextMessageAsync(message.Chat.Id, "Укажите название розыгрыша после команды /create");
            return;
        }

        string giveawayName = string.Join(" ", parts.Skip(1));
        var raffle = new Raffle(giveawayName);
        raffles.Add(raffle);
        SaveRaffles();
        await client.SendTextMessageAsync(message.Chat.Id, $"Розыгрыш '{giveawayName}' создан!");
    }

    private static async Task DeleteRaffle(ITelegramBotClient client, Message message)
    {
        var parts = message.Text.Trim().Split(' ');
        if (parts.Length < 2)
        {
            await client.SendTextMessageAsync(message.Chat.Id, "Укажите название розыгрыша после команды /delete");
            return;
        }

        string giveawayName = string.Join(" ", parts.Skip(1));
        var raffle = raffles.FirstOrDefault(r => r.Name.Equals(giveawayName, StringComparison.OrdinalIgnoreCase));

        if (raffle != null)
        {
            raffles.Remove(raffle);
            SaveRaffles();
            await client.SendTextMessageAsync(message.Chat.Id, $"Розыгрыш '{giveawayName}' удалён.");
        }
        else
        {
            await client.SendTextMessageAsync(message.Chat.Id, $"Розыгрыш '{giveawayName}' не найден.");
        }
    }

    private static async Task SetRaffleImage(ITelegramBotClient client, Message message)
    {
        var parts = message.Text.Trim().Split(' ');
        if (parts.Length < 3)
        {
            await client.SendTextMessageAsync(message.Chat.Id, "Использование: /setimage имя URL");
            return;
        }

        string raffleName = parts[1];
        string imageUrl = parts[2];
        await UpdateRaffleProperty(client, message, raffleName, r => r.ImageURL = imageUrl,
            $"Картинка для розыгрыша \"{raffleName}\" установлена.");
    }

    private static async Task EditRaffleName(ITelegramBotClient client, Message message)
    {
        var parts = message.Text.Trim().Split(' ');
        if (parts.Length < 3)
        {
            await client.SendTextMessageAsync(message.Chat.Id, "Использование: /edit OLDname NEWname");
            return;
        }

        string oldName = parts[1];
        string newName = string.Join(" ", parts.Skip(2));
        await UpdateRaffleProperty(client, message, oldName, r => r.Name = newName,
            $"Название розыгрыша изменено на '{newName}'.");
    }

    private static async Task SetRaffleTime(ITelegramBotClient client, Message message)
    {
        var parts = message.Text.Trim().Split(' ');
        if (parts.Length < 3)
        {
            await client.SendTextMessageAsync(message.Chat.Id, "Использование: /settime имя HH:mm");
            return;
        }

        string raffleName = parts[1];
        string timeStr = parts[2];
        if (!TimeSpan.TryParse(timeStr, out var scheduledTime))
        {
            await client.SendTextMessageAsync(message.Chat.Id, "Укажите время в формате HH:mm");
            return;
        }

        await UpdateRaffleProperty(client, message, raffleName, r => r.ScheduledTime = scheduledTime,
            $"Время розыгрыша \"{raffleName}\" установлено на {timeStr}");
    }

    private static async Task StartRaffle(ITelegramBotClient client, Message message)
    {
        var parts = message.Text.Trim().Split(' ');
        if (parts.Length < 2)
        {
            await client.SendTextMessageAsync(message.Chat.Id, "Укажите название розыгрыша после команды /starte");
            return;
        }

        string raffleName = string.Join(" ", parts.Skip(1));
        var raffle = raffles.FirstOrDefault(r => r.Name.Equals(raffleName, StringComparison.OrdinalIgnoreCase));

        if (raffle != null)
        {
            if (raffle.ScheduledTime <= DateTime.Now.TimeOfDay)
            {
                await SelectWinner(client, raffle);
                raffles.Remove(raffle);
                raffleHistory.Add(raffle);
                SaveRaffles();
                SaveRaffleHistory();
            }
            else
            {
                await client.SendTextMessageAsync(message.Chat.Id, $"Розыгрыш \"{raffle.Name}\" не может быть запущен до {raffle.ScheduledTime}");
            }
        }
        else
        {
            await client.SendTextMessageAsync(message.Chat.Id, $"Розыгрыш '{raffleName}' не найден.");
        }
    }

    private static async Task UpdateRaffleProperty(ITelegramBotClient client, Message message, string raffleName, Action<Raffle> updateAction, string successMessage)
    {
        var raffle = raffles.FirstOrDefault(r => r.Name.Equals(raffleName, StringComparison.OrdinalIgnoreCase));
        if (raffle != null)
        {
            updateAction(raffle);
            SaveRaffles();
            await client.SendTextMessageAsync(message.Chat.Id, successMessage);
        }
        else
        {
            await client.SendTextMessageAsync(message.Chat.Id, $"Розыгрыш '{raffleName}' не найден.");
        }
    }

    private static async Task HandleCallbackQuery(ITelegramBotClient client, CallbackQuery callbackQuery)
    {
        if (callbackQuery?.Data == null) return;

        var parts = callbackQuery.Data.Split('_');
        switch (callbackQuery.Data)
        {
            case "show_history":
                await ShowHistory(callbackQuery, client);
                break;
            case "close":
                await client.DeleteMessageAsync(callbackQuery.Message.Chat.Id, callbackQuery.Message.MessageId);
                break;
            default:
                await HandleParticipantActions(callbackQuery, client, parts);
                break;
        }
    }

    private static async Task ShowHistory(CallbackQuery callbackQuery, ITelegramBotClient client)
    {
        // Удаляем текущее сообщение с кнопкой и показываем историю розыгрышей
        await client.DeleteMessageAsync(callbackQuery.Message.Chat.Id, callbackQuery.Message.MessageId);
        await ShowRaffleHistory(client, callbackQuery.Message.Chat.Id);
    }

    private static async Task HandleParticipantActions(CallbackQuery callbackQuery, ITelegramBotClient client, string[] parts)
    {
        if (parts.Length != 2) return;

        string action = parts[0];
        string raffleName = parts[1];
        var raffle = raffles.FirstOrDefault(r => r.Name.Equals(raffleName, StringComparison.OrdinalIgnoreCase));

        if (raffle != null)
        {
            long participantId = callbackQuery.From.Id;
            if (action == "participate")
            {
                await ParticipateInRaffle(callbackQuery, client, raffle, participantId);
            }
            else if (action == "withdraw")
            {
                await WithdrawFromRaffle(callbackQuery, client, raffle, participantId);
            }
        }
        else
        {
            await client.AnswerCallbackQueryAsync(callbackQuery.Id, "Розыгрыш уже завершён или не найден.");
            await client.DeleteMessageAsync(callbackQuery.Message.Chat.Id, callbackQuery.Message.MessageId);
        }
    }

    private static async Task ParticipateInRaffle(CallbackQuery callbackQuery, ITelegramBotClient client, Raffle raffle, long participantId)
    {
        if (!raffle.ParticipantIds.Contains(participantId))
        {
            raffle.ParticipantIds.Add(participantId);
            raffle.Participants.Add(callbackQuery.From.Username ?? "Аноним");
            SaveRaffles();
            await client.AnswerCallbackQueryAsync(callbackQuery.Id, "Вы успешно участвуете в розыгрыше!");
        }
        else
        {
            await client.AnswerCallbackQueryAsync(callbackQuery.Id, "Вы уже участвуете в этом розыгрыше.");
        }
    }

    private static async Task WithdrawFromRaffle(CallbackQuery callbackQuery, ITelegramBotClient client, Raffle raffle, long participantId)
    {
        if (raffle.ParticipantIds.Contains(participantId))
        {
            raffle.ParticipantIds.Remove(participantId);
            raffle.Participants.Remove(callbackQuery.From.Username ?? "Аноним");
            SaveRaffles();
            await client.AnswerCallbackQueryAsync(callbackQuery.Id, "Вы покинули розыгрыш.");
        }
        else
        {
            await client.AnswerCallbackQueryAsync(callbackQuery.Id, "Вы не участвуете в этом розыгрыше.");
        }
    }

    private static async Task ShowRaffleHistory(ITelegramBotClient client, long chatId)
    {
        if (!raffleHistory.Any())
        {
            await client.SendTextMessageAsync(chatId, "История розыгрышей пуста.");
            return;
        }

        var buttons = raffleHistory.Select(r => InlineKeyboardButton.WithCallbackData(r.Name, $"history_{r.Name}")).ToList();
        var keyboard = new InlineKeyboardMarkup(buttons.Concat(new[] { InlineKeyboardButton.WithCallbackData("Закрыть", "close") }));
        await client.SendTextMessageAsync(chatId, "Выберите розыгрыш из истории:", replyMarkup: keyboard);
    }

    private static async Task ShowRaffles(ITelegramBotClient client, long chatId)
    {
        if (!raffles.Any())
        {
            await client.SendTextMessageAsync(chatId, "На данный момент розыгрыши недоступны.");
            return;
        }

        foreach (var raffle in raffles)
        {
            await ShowRaffleDetails(client, chatId, raffle);
        }
    }

    private static async Task ShowRaffleDetails(ITelegramBotClient client, long chatId, Raffle raffle)
    {
        var keyboard = RaffleActionButtons(raffle.Name);
        string messageText = $"Розыгрыш: {raffle.Name}\nКоличество участников: {raffle.Participants.Count}\nЗапланированное время: {raffle.ScheduledTime}";

        if (!string.IsNullOrEmpty(raffle.ImageURL))
        {
            await SendRafflePhoto(client, chatId, raffle, messageText, keyboard);
        }
        else
        {
            await client.SendTextMessageAsync(chatId, messageText, replyMarkup: keyboard);
        }
    }

    private static async Task SendRafflePhoto(ITelegramBotClient client, long chatId, Raffle raffle, string messageText, InlineKeyboardMarkup keyboard)
    {
        try
        {
            var photo = new InputFileUrl(raffle.ImageURL);
            await client.SendPhotoAsync(chatId, photo, caption: messageText, replyMarkup: keyboard);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при отправке изображения: {ex.Message}");
            await client.SendTextMessageAsync(chatId, messageText, replyMarkup: keyboard);
        }
    }

    private static InlineKeyboardMarkup RaffleActionButtons(string raffleName)
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData("Участвовать", $"participate_{raffleName}"),
                InlineKeyboardButton.WithCallbackData("Отписаться", $"withdraw_{raffleName}")
            }
        });
    }

    private static void LoadRaffles()
    {
        if (System.IO.File.Exists(jsonFilePath))
        {
            var json = System.IO.File.ReadAllText(jsonFilePath);
            raffles = JsonSerializer.Deserialize<List<Raffle>>(json) ?? new List<Raffle>();
        }

        if (System.IO.File.Exists(historyJsonFilePath))
        {
            var json = System.IO.File.ReadAllText(historyJsonFilePath);
            raffleHistory = JsonSerializer.Deserialize<List<Raffle>>(json) ?? new List<Raffle>();
        }
    }

    private static void SaveRaffles()
    {
        var json = JsonSerializer.Serialize(raffles);
        System.IO.File.WriteAllText(jsonFilePath, json);
    }

    private static void SaveRaffleHistory()
    {
        var json = JsonSerializer.Serialize(raffleHistory);
        System.IO.File.WriteAllText(historyJsonFilePath, json);
    }

    private static InlineKeyboardMarkup AdminPanel()
    {
        return new InlineKeyboardMarkup(new[]
        {
            new[]
            {
                InlineKeyboardButton.WithCallbackData("Запустить розыгрыш", "/starte имя")
            }
        });
    }

    private static Task ErrorHandler(ITelegramBotClient client, Exception exception, CancellationToken token)
    {
        Console.WriteLine($"Ошибка: {exception.Message}");
        return Task.CompletedTask;
    }

    private static async Task SelectWinner(ITelegramBotClient client, Raffle raffle)
    {
        if (!raffle.Participants.Any())
        {
            await NotifyNoParticipants(client, raffle);
            return;
        }

        raffle.RaffleTime = DateTime.Now;
        int winnerIndex = new Random().Next(raffle.Participants.Count);
        string winnerName = raffle.Participants[winnerIndex];
        long winnerId = raffle.ParticipantIds[winnerIndex];

        string messageText = $"Поздравляем! Вы победитель розыгрыша '{raffle.Name}'!";
        await client.SendTextMessageAsync((int)winnerId, messageText);
        await NotifyAllParticipants(client, raffle, winnerId, winnerName);
    }

    private static async Task NotifyNoParticipants(ITelegramBotClient client, Raffle raffle)
    {
        string noParticipantsMessage = $"В розыгрыше '{raffle.Name}' нет участников.";
        foreach (var participantId in raffle.ParticipantIds)
        {
            await client.SendTextMessageAsync((int)participantId, noParticipantsMessage);
        }
    }

    private static async Task NotifyAllParticipants(ITelegramBotClient client, Raffle raffle, long winnerId, string winnerName)
    {
        string participantList = string.Join(", ", raffle.Participants);
        foreach (var participantId in raffle.ParticipantIds)
        {
            string resultMessage = participantId == winnerId
                ? $"Поздравляем, вы победили в розыгрыше '{raffle.Name}'."
                : $"Вы не выиграли в розыгрыше '{raffle.Name}'. Спасибо за участие!";
            await client.SendTextMessageAsync((int)participantId, resultMessage);
        }

        foreach (var participantId in raffle.ParticipantIds)
        {
            await client.SendTextMessageAsync((int)participantId, $"Результаты розыгрыша '{raffle.Name}'\nПобедитель - {winnerName}.\n\nПолный список участников: {participantList}");
        }
    }

    public class Raffle
    {
        public string Name { get; set; }
        public List<string> Participants { get; set; }
        public List<long> ParticipantIds { get; set; }
        public TimeSpan? ScheduledTime { get; set; }
        public DateTime? RaffleTime { get; set; }
        public string ImageURL { get; set; }

        public Raffle(string name)
        {
            Name = name;
            Participants = new List<string>();
            ParticipantIds = new List<long>();
        }
    }
}